import { createContext, useContext, useMemo, useState } from "react";
import { api } from "../services/api";

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem("tf_user") || "null"));
  const [loading, setLoading] = useState(false);

  async function authenticate(path, values) {
    setLoading(true);
    try {
      const res = await api.post(`/auth/${path}`, values);
      localStorage.setItem("tf_access", res.data.data.accessToken);
      localStorage.setItem("tf_refresh", res.data.data.refreshToken);
      localStorage.setItem("tf_user", JSON.stringify(res.data.data.user));
      setUser(res.data.data.user);
    } finally {
      setLoading(false);
    }
  }

  async function logout() {
    try { await api.post("/auth/logout"); } catch {}
    localStorage.removeItem("tf_access"); localStorage.removeItem("tf_refresh"); localStorage.removeItem("tf_user");
    setUser(null);
  }

  const value = useMemo(() => ({ user, loading, login: (v) => authenticate("login", v), register: (v) => authenticate("register", v), logout, setUser }), [user, loading]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
