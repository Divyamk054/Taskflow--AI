export function StatCard({ label, value, tone = "" }) {
  return <section className={`stat ${tone}`}><span>{label}</span><strong>{value}</strong></section>;
}
