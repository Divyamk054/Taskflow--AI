export function Loading() { return <div className="state">Loading workspace data...</div>; }
export function ErrorState({ message }) { return <div className="state error">{message || "Something went wrong"}</div>; }
export function EmptyState({ label }) { return <div className="state">{label}</div>; }
