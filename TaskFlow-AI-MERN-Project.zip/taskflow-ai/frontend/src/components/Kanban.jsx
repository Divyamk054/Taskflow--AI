import { Trash2 } from "lucide-react";
import { formatDate } from "../utils/format";

const columns = ["todo", "in_progress", "review", "done"];

export function Kanban({ tasks = [], onMove, onDelete }) {
  return (
    <div className="kanban">
      {columns.map((status) => (
        <section className="column" key={status}>
          <h3>{status.replace("_", " ")}</h3>
          {tasks.filter((task) => task.status === status).map((task) => (
            <article className="task-card" key={task._id}>
              <div className="card-head">
                <strong>{task.title}</strong>
                <button className="icon danger" title="Delete task" onClick={() => onDelete(task)}><Trash2 size={15} /></button>
              </div>
              <p>{task.description || "No description yet"}</p>
              <div className="meta">
                <span>{task.priority}</span>
                {task.assignedTo?.name && <span>{task.assignedTo.name}</span>}
                {task.dueDate && <span>{formatDate(task.dueDate)}</span>}
              </div>
              <select value={task.status} onChange={(e) => onMove(task, e.target.value)}>{columns.map((column) => <option key={column}>{column}</option>)}</select>
            </article>
          ))}
        </section>
      ))}
    </div>
  );
}
