import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ErrorState, Loading } from "../components/State";
import { useApi } from "../hooks/useApi";
import { api } from "../services/api";

export function Analytics() {
  const { data, loading, error } = useApi(async () => (await api.get("/analytics")).data.data, []);
  if (loading) return <Loading />; if (error) return <ErrorState message={error} />;
  return <div className="page"><h1>Analytics</h1><section className="panel"><h2>Tasks by Status</h2><ResponsiveContainer width="100%" height={320}><BarChart data={data.byStatus.map((x)=>({name:x._id,count:x.count}))}><XAxis dataKey="name"/><YAxis/><Tooltip/><Bar dataKey="count" fill="#20c997"/></BarChart></ResponsiveContainer></section></div>;
}
