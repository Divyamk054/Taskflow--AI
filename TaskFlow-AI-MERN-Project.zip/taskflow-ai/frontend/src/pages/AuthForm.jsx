import { motion } from "framer-motion";
import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import { useAuth } from "../context/AuthContext";

export function AuthForm({ mode }) {
  const isLogin = mode === "login";
  const { login, register, loading } = useAuth();
  const navigate = useNavigate();
  const [error, setError] = useState("");
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "member" });
  async function submit(e) {
    e.preventDefault(); setError("");
    try { await (isLogin ? login(form) : register(form)); navigate("/dashboard"); } catch (err) { setError(err.response?.data?.message || err.message); }
  }
  return <div className="auth"><motion.form initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} onSubmit={submit}>
    <h1>TaskFlow AI</h1><p>{isLogin ? "Sign in to your command center." : "Create your workspace account."}</p>
    {!isLogin && <input placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />}
    <input placeholder="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
    <input placeholder="Password" type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
    {!isLogin && <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}><option>member</option><option>manager</option><option>admin</option></select>}
    {error && <div className="inline-error">{error}</div>}<button disabled={loading}>{loading ? "Working..." : isLogin ? "Login" : "Create account"}</button>
    <Link to={isLogin ? "/register" : "/login"}>{isLogin ? "Need an account?" : "Already registered?"}</Link>
  </motion.form></div>;
}
