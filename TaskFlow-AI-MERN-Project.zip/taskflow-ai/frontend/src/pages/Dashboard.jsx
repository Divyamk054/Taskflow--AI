import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { api } from "../services/api";
import { useApi } from "../hooks/useApi";
import { ErrorState, Loading } from "../components/State";
import { StatCard } from "../components/StatCard";

export function Dashboard() {
  const { data, loading, error } = useApi(async () => (await api.get("/analytics")).data.data, []);
  if (loading) return <Loading />; if (error) return <ErrorState message={error} />;
  return <div className="page"><h1>Dashboard</h1><div className="stats"><StatCard label="Total Projects" value={data.totalProjects}/><StatCard label="Total Tasks" value={data.totalTasks}/><StatCard label="Completed" value={data.completedTasks} tone="good"/><StatCard label="Pending" value={data.pendingTasks}/><StatCard label="Productivity" value={`${data.teamProductivity}%`} tone="accent"/></div><section className="panel"><h2>Weekly Progress</h2><ResponsiveContainer width="100%" height={260}><AreaChart data={data.weeklyProgress}><XAxis dataKey="day"/><Tooltip/><Area dataKey="completed" stroke="#4f8cff" fill="#4f8cff33"/></AreaChart></ResponsiveContainer></section></div>;
}
