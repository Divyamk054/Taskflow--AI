import { Pencil, Plus, Search, Trash2 } from "lucide-react";
import { useState } from "react";
import { ErrorState, Loading } from "../components/State";
import { useApi } from "../hooks/useApi";
import { api } from "../services/api";

const initialForm = { title: "", description: "", status: "active" };
const statuses = ["planning", "active", "on_hold", "completed", "archived"];

export function Projects() {
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [form, setForm] = useState(initialForm);
  const { data, loading, error, reload } = useApi(async () => (await api.get(`/projects?page=${page}&limit=6&search=${encodeURIComponent(search)}`)).data.data, [page, search]);

  async function create(e) {
    e.preventDefault();
    await api.post("/projects", form);
    setForm(initialForm);
    reload();
  }

  async function update(project, patch) {
    await api.patch(`/projects/${project._id}`, patch);
    reload();
  }

  async function remove(project) {
    if (!confirm(`Delete project "${project.title}" and its tasks?`)) return;
    await api.delete(`/projects/${project._id}`);
    reload();
  }

  if (loading) return <Loading />;
  if (error) return <ErrorState message={error} />;

  return (
    <div className="page">
      <h1>Projects</h1>
      <div className="toolbar">
        <label>
          <Search size={16} />
          <input placeholder="Search projects" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} />
        </label>
        <form onSubmit={create}>
          <input required placeholder="New project" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <input placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>{statuses.map((status) => <option key={status}>{status}</option>)}</select>
          <button><Plus size={16} />Add</button>
        </form>
      </div>
      <div className="grid">
        {data.items.map((project) => (
          <article className="project" key={project._id}>
            <div className="card-head">
              <strong>{project.title}</strong>
              <button className="icon danger" title="Delete project" onClick={() => remove(project)}><Trash2 size={16} /></button>
            </div>
            <p>{project.description || "No description yet"}</p>
            <div className="row">
              <span>{project.status}</span>
              <select value={project.status} onChange={(e) => update(project, { status: e.target.value })}>{statuses.map((status) => <option key={status}>{status}</option>)}</select>
            </div>
            <progress value={project.status === "completed" ? 100 : project.status === "active" ? 62 : 28} max="100" />
            <button className="secondary" onClick={() => update(project, { title: `${project.title} Updated` })}><Pencil size={16} />Quick edit</button>
          </article>
        ))}
      </div>
      <div className="pager">
        <button disabled={page === 1} onClick={() => setPage(page - 1)}>Prev</button>
        <span>{page} / {data.pages}</span>
        <button disabled={page >= data.pages} onClick={() => setPage(page + 1)}>Next</button>
      </div>
    </div>
  );
}
