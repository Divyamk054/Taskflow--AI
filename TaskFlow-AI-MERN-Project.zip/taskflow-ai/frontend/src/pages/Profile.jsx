import { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { api } from "../services/api";

export function Profile() {
  const { user, setUser } = useAuth(); const [form, setForm] = useState({ name: user.name, avatar: user.avatar || "" });
  async function save(e) { e.preventDefault(); const res = await api.patch("/users/me", form); setUser(res.data.data); localStorage.setItem("tf_user", JSON.stringify(res.data.data)); }
  return <div className="page"><h1>Profile</h1><form className="panel form" onSubmit={save}><input value={form.name} onChange={(e)=>setForm({...form,name:e.target.value})}/><input placeholder="Avatar URL" value={form.avatar} onChange={(e)=>setForm({...form,avatar:e.target.value})}/><button>Save Profile</button></form></div>;
}
