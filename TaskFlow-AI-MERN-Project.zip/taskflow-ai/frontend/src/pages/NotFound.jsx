import { Link } from "react-router-dom";
export function NotFound() { return <div className="auth"><div className="notfound"><h1>404</h1><p>That page does not exist.</p><Link to="/dashboard">Back to dashboard</Link></div></div>; }
