import { Plus, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { Kanban } from "../components/Kanban";
import { ErrorState, Loading } from "../components/State";
import { useApi } from "../hooks/useApi";
import { api } from "../services/api";

const initialForm = { title: "", description: "", projectId: "", assignedTo: "", dueDate: "", priority: "medium" };

export function Tasks() {
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [files, setFiles] = useState([]);
  const [form, setForm] = useState(initialForm);
  const { data, loading, error, reload } = useApi(async () => {
    const [tasks, projects] = await Promise.all([
      api.get(`/tasks?page=${page}&limit=40&search=${encodeURIComponent(search)}`),
      api.get("/projects?limit=100")
    ]);
    return { tasks: tasks.data.data, projects: projects.data.data.items };
  }, [page, search]);

  const selectedProject = useMemo(() => data?.projects.find((project) => project._id === form.projectId), [data, form.projectId]);

  async function create(e) {
    e.preventDefault();
    const payload = new FormData();
    Object.entries(form).forEach(([key, value]) => { if (value) payload.append(key, value); });
    files.forEach((file) => payload.append("attachments", file));
    await api.post("/tasks", payload);
    setForm(initialForm);
    setFiles([]);
    reload();
  }

  async function move(task, status) {
    await api.patch(`/tasks/${task._id}`, { status });
    reload();
  }

  async function remove(task) {
    if (!confirm(`Delete task "${task.title}"?`)) return;
    await api.delete(`/tasks/${task._id}`);
    reload();
  }

  if (loading) return <Loading />;
  if (error) return <ErrorState message={error} />;

  return (
    <div className="page">
      <h1>Tasks</h1>
      <div className="toolbar">
        <label>
          <Search size={16} />
          <input placeholder="Search tasks" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} />
        </label>
      </div>
      <form className="toolbar task-form" onSubmit={create}>
        <input required placeholder="Task title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        <input placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
        <select required value={form.projectId} onChange={(e) => setForm({ ...form, projectId: e.target.value, assignedTo: "" })}>
          <option value="">Project</option>
          {data.projects.map((project) => <option key={project._id} value={project._id}>{project.title}</option>)}
        </select>
        <select value={form.assignedTo} onChange={(e) => setForm({ ...form, assignedTo: e.target.value })}>
          <option value="">Unassigned</option>
          {(selectedProject?.members || []).map((member) => <option key={member._id} value={member._id}>{member.name}</option>)}
        </select>
        <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>
          {["low", "medium", "high", "urgent"].map((priority) => <option key={priority}>{priority}</option>)}
        </select>
        <input type="date" value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} />
        <input type="file" multiple onChange={(e) => setFiles(Array.from(e.target.files || []))} />
        <button><Plus size={16} />Create Task</button>
      </form>
      <Kanban tasks={data.tasks.items} onMove={move} onDelete={remove} />
      <div className="pager">
        <button disabled={page === 1} onClick={() => setPage(page - 1)}>Prev</button>
        <span>{page} / {data.tasks.pages}</span>
        <button disabled={page >= data.tasks.pages} onClick={() => setPage(page + 1)}>Next</button>
      </div>
    </div>
  );
}
