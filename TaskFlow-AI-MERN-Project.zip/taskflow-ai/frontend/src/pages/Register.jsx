import { AuthForm } from "./AuthForm";
export function Register() { return <AuthForm mode="register" />; }
