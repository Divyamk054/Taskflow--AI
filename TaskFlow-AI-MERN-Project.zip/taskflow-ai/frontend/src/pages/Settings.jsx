import { useTheme } from "../context/ThemeContext";
export function Settings() { const { dark, setDark } = useTheme(); return <div className="page"><h1>Settings</h1><section className="panel"><label className="switch"><input type="checkbox" checked={dark} onChange={(e)=>setDark(e.target.checked)}/>Dark mode</label></section></div>; }
