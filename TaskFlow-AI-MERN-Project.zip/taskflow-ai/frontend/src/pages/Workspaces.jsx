import { Plus, Search } from "lucide-react";
import { useState } from "react";
import { ErrorState, Loading } from "../components/State";
import { useApi } from "../hooks/useApi";
import { api } from "../services/api";

export function Workspaces() {
  const [search, setSearch] = useState("");
  const [form, setForm] = useState({ name: "", description: "" });
  const { data = [], loading, error, reload } = useApi(async () => (await api.get("/workspaces")).data.data, []);
  const filtered = data.filter((workspace) => `${workspace.name} ${workspace.description}`.toLowerCase().includes(search.toLowerCase()));

  async function create(e) {
    e.preventDefault();
    await api.post("/workspaces", form);
    setForm({ name: "", description: "" });
    reload();
  }

  if (loading) return <Loading />;
  if (error) return <ErrorState message={error} />;

  return (
    <div className="page">
      <h1>Workspaces</h1>
      <div className="toolbar">
        <label>
          <Search size={16} />
          <input placeholder="Search workspaces" value={search} onChange={(e) => setSearch(e.target.value)} />
        </label>
        <form onSubmit={create}>
          <input required placeholder="Workspace name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <input placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <button><Plus size={16} />Create</button>
        </form>
      </div>
      <div className="grid">
        {filtered.map((workspace) => (
          <article className="project" key={workspace._id}>
            <strong>{workspace.name}</strong>
            <p>{workspace.description || "Team workspace"}</p>
            <span>{workspace.members?.length || 0} members</span>
          </article>
        ))}
      </div>
    </div>
  );
}
