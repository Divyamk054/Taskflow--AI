import { BarChart3, LayoutDashboard, ListTodo, LogOut, Moon, Settings, User, Workflow, Building2 } from "lucide-react";
import { NavLink, Outlet } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useTheme } from "../context/ThemeContext";

const links = [["/dashboard", LayoutDashboard, "Dashboard"], ["/workspaces", Building2, "Workspaces"], ["/projects", Workflow, "Projects"], ["/tasks", ListTodo, "Tasks"], ["/analytics", BarChart3, "Analytics"], ["/profile", User, "Profile"], ["/settings", Settings, "Settings"]];

export function AppLayout() {
  const { user, logout } = useAuth();
  const { dark, setDark } = useTheme();
  return <div className="shell">
    <aside className="sidebar"><div className="brand">TaskFlow AI</div>{links.map(([to, Icon, label]) => <NavLink key={to} to={to}><Icon size={18}/>{label}</NavLink>)}</aside>
    <main className="main">
      <header className="topbar"><div><strong>{user?.name}</strong><span>{user?.role}</span></div><button title="Toggle dark mode" onClick={() => setDark(!dark)}><Moon size={18}/></button><button title="Logout" onClick={logout}><LogOut size={18}/></button></header>
      <Outlet />
    </main>
  </div>;
}
