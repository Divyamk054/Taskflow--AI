import axios from "axios";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api/v1";
export const api = axios.create({ baseURL: API_URL, withCredentials: true });

api.interceptors.request.use((config) => {
  const accessToken = localStorage.getItem("tf_access");
  if (accessToken) config.headers.Authorization = `Bearer ${accessToken}`;
  return config;
});

api.interceptors.response.use(undefined, async (error) => {
  const original = error.config;
  if (error.response?.status === 401 && original && !original._retry) {
    original._retry = true;
    const res = await axios.post(`${API_URL}/auth/refresh`, { refreshToken: localStorage.getItem("tf_refresh") }, { withCredentials: true });
    localStorage.setItem("tf_access", res.data.data.accessToken);
    localStorage.setItem("tf_refresh", res.data.data.refreshToken);
    original.headers.Authorization = `Bearer ${res.data.data.accessToken}`;
    return api(original);
  }
  return Promise.reject(error);
});
