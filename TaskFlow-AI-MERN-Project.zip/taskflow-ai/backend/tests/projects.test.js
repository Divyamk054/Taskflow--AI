import request from "supertest";
import { app } from "../src/app.js";

async function token() {
  const res = await request(app).post("/api/v1/auth/register").send({ name: "Grace Hopper", email: "grace@example.com", password: "Password123", role: "manager" });
  return res.body.data.accessToken;
}

test("creates and paginates projects", async () => {
  const access = await token();
  await request(app).post("/api/v1/projects").set("Authorization", `Bearer ${access}`).send({ title: "Compiler", description: "Ship it", status: "active" }).expect(201);
  const list = await request(app).get("/api/v1/projects?page=1&limit=5&search=Compiler").set("Authorization", `Bearer ${access}`).expect(200);
  expect(list.body.data.items).toHaveLength(1);
});

test("scopes tasks and analytics to accessible projects", async () => {
  const owner = await token();
  const outsider = (await request(app).post("/api/v1/auth/register").send({ name: "Katherine Johnson", email: "kj@example.com", password: "Password123" })).body.data.accessToken;
  const project = await request(app).post("/api/v1/projects").set("Authorization", `Bearer ${owner}`).send({ title: "Apollo", status: "active" }).expect(201);
  const task = await request(app).post("/api/v1/tasks").set("Authorization", `Bearer ${owner}`).send({ title: "Trajectory review", projectId: project.body.data._id, status: "todo" }).expect(201);

  const outsiderTasks = await request(app).get("/api/v1/tasks").set("Authorization", `Bearer ${outsider}`).expect(200);
  expect(outsiderTasks.body.data.total).toBe(0);
  await request(app).patch(`/api/v1/tasks/${task.body.data._id}`).set("Authorization", `Bearer ${outsider}`).send({ status: "done" }).expect(404);

  const ownerAnalytics = await request(app).get("/api/v1/analytics").set("Authorization", `Bearer ${owner}`).expect(200);
  const outsiderAnalytics = await request(app).get("/api/v1/analytics").set("Authorization", `Bearer ${outsider}`).expect(200);
  expect(ownerAnalytics.body.data.totalTasks).toBe(1);
  expect(outsiderAnalytics.body.data.totalTasks).toBe(0);
});
