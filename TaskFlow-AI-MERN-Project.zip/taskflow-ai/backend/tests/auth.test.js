import request from "supertest";
import { app } from "../src/app.js";

test("registers, logs in, and returns profile", async () => {
  const payload = { name: "Ada Lovelace", email: "ada@example.com", password: "Password123" };
  const register = await request(app).post("/api/v1/auth/register").send(payload).expect(201);
  expect(register.body.data.accessToken).toBeTruthy();
  const login = await request(app).post("/api/v1/auth/login").send({ email: payload.email, password: payload.password }).expect(200);
  await request(app).get("/api/v1/auth/me").set("Authorization", `Bearer ${login.body.data.accessToken}`).expect(200);
});
