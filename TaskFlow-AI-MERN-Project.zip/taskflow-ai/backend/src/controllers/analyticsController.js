import { Project } from "../models/Project.js";
import { Task } from "../models/Task.js";

export async function analytics(req, res, next) {
  try {
    const projectIds = (await Project.find({ $or: [{ owner: req.user.id }, { members: req.user.id }] }).select("_id")).map((project) => project._id);
    const taskScope = { projectId: { $in: projectIds } };
    const [totalProjects, totalTasks, completedTasks, pendingTasks, byStatus, byPriority] = await Promise.all([
      Project.countDocuments({ $or: [{ owner: req.user.id }, { members: req.user.id }] }),
      Task.countDocuments(taskScope),
      Task.countDocuments({ ...taskScope, status: "done" }),
      Task.countDocuments({ ...taskScope, status: { $ne: "done" } }),
      Task.aggregate([{ $match: taskScope }, { $group: { _id: "$status", count: { $sum: 1 } } }]),
      Task.aggregate([{ $match: taskScope }, { $group: { _id: "$priority", count: { $sum: 1 } } }])
    ]);
    const weeklyProgress = Array.from({ length: 7 }, (_, i) => ({ day: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"][i], completed: Math.max(0, completedTasks - (6 - i)) }));
    res.json({ success: true, data: { totalProjects, totalTasks, completedTasks, pendingTasks, teamProductivity: totalTasks ? Math.round((completedTasks / totalTasks) * 100) : 0, byStatus, byPriority, weeklyProgress } });
  } catch (error) { next(error); }
}
