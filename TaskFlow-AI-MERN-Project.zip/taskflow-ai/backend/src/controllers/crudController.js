import { Project } from "../models/Project.js";
import { Task } from "../models/Task.js";
import { Workspace } from "../models/Workspace.js";
import { Comment } from "../models/Comment.js";
import { Notification } from "../models/Notification.js";
import { AppError } from "../utils/AppError.js";
import { paginated } from "../services/query.js";

const ownership = (req) => ({ $or: [{ owner: req.user.id }, { members: req.user.id }] });
const cleanOptional = (body) => Object.fromEntries(Object.entries(body).filter(([, value]) => value !== ""));

async function accessibleProjectIds(req) {
  const projects = await Project.find(ownership(req)).select("_id");
  return projects.map((project) => project._id);
}

async function assertProjectAccess(projectId, req) {
  const project = await Project.findOne({ _id: projectId, ...ownership(req) });
  if (!project) throw new AppError("Project not found or access denied", 404);
  return project;
}

async function taskAccessFilter(req, taskId) {
  const projectIds = await accessibleProjectIds(req);
  return { _id: taskId, projectId: { $in: projectIds } };
}

export async function listWorkspaces(req, res, next) { try { res.json({ success: true, data: await Workspace.find(ownership(req)).populate("members", "name email avatar") }); } catch (e) { next(e); } }
export async function createWorkspace(req, res, next) { try { res.status(201).json({ success: true, data: await Workspace.create({ ...req.body, owner: req.user.id, members: [req.user.id, ...(req.body.members || [])] }) }); } catch (e) { next(e); } }

export async function listProjects(req, res, next) { try { res.json({ success: true, data: await paginated(Project, ownership(req), req, [{ path: "owner members", select: "name email avatar" }]) }); } catch (e) { next(e); } }
export async function createProject(req, res, next) { try { res.status(201).json({ success: true, data: await Project.create({ ...req.body, owner: req.user.id, members: [req.user.id, ...(req.body.members || [])] }) }); } catch (e) { next(e); } }
export async function updateProject(req, res, next) { try { const item = await Project.findOneAndUpdate({ _id: req.params.id, ...ownership(req) }, req.body, { new: true, runValidators: true }); if (!item) throw new AppError("Project not found", 404); res.json({ success: true, data: item }); } catch (e) { next(e); } }
export async function deleteProject(req, res, next) { try { const item = await Project.findOneAndDelete({ _id: req.params.id, ...ownership(req) }); if (!item) throw new AppError("Project not found", 404); await Task.deleteMany({ projectId: item.id }); res.status(204).send(); } catch (e) { next(e); } }

export async function listTasks(req, res, next) {
  try {
    const projectIds = await accessibleProjectIds(req);
    const filter = req.query.projectId
      ? { projectId: { $in: projectIds.filter((id) => id.equals(req.query.projectId)) } }
      : { projectId: { $in: projectIds } };
    res.json({ success: true, data: await paginated(Task, filter, req, [{ path: "assignedTo", select: "name email avatar" }, { path: "projectId", select: "title" }]) });
  } catch (e) { next(e); }
}

export async function createTask(req, res, next) {
  try {
    const body = cleanOptional(req.body);
    const project = await assertProjectAccess(body.projectId, req);
    if (body.assignedTo && !project.members.some((member) => member.equals(body.assignedTo))) throw new AppError("Assignee must be a project member", 400);
    const task = await Task.create({ ...body, attachments: (req.files || []).map((file) => ({ filename: file.originalname, path: file.path, mimetype: file.mimetype, size: file.size })) });
    if (task.assignedTo) await Notification.create({ userId: task.assignedTo, message: `New task assigned: ${task.title}` });
    res.status(201).json({ success: true, data: task });
  } catch (e) { next(e); }
}

export async function updateTask(req, res, next) {
  try {
    const body = cleanOptional(req.body);
    const existing = await Task.findOne(await taskAccessFilter(req, req.params.id));
    if (!existing) throw new AppError("Task not found", 404);
    const project = await assertProjectAccess(body.projectId || existing.projectId, req);
    if (body.assignedTo && !project.members.some((member) => member.equals(body.assignedTo))) throw new AppError("Assignee must be a project member", 400);
    const item = await Task.findByIdAndUpdate(existing.id, body, { new: true, runValidators: true });
    if (body.assignedTo && String(body.assignedTo) !== String(existing.assignedTo || "")) await Notification.create({ userId: body.assignedTo, message: `Task updated: ${item.title}` });
    res.json({ success: true, data: item });
  } catch (e) { next(e); }
}

export async function deleteTask(req, res, next) {
  try {
    const item = await Task.findOneAndDelete(await taskAccessFilter(req, req.params.id));
    if (!item) throw new AppError("Task not found", 404);
    res.status(204).send();
  } catch (e) { next(e); }
}

export async function listComments(req, res, next) { try { const task = await Task.findOne(await taskAccessFilter(req, req.params.taskId)); if (!task) throw new AppError("Task not found", 404); res.json({ success: true, data: await Comment.find({ taskId: req.params.taskId }).populate("userId", "name avatar").sort({ createdAt: -1 }) }); } catch (e) { next(e); } }
export async function createComment(req, res, next) { try { const task = await Task.findOne(await taskAccessFilter(req, req.body.taskId)); if (!task) throw new AppError("Task not found", 404); res.status(201).json({ success: true, data: await Comment.create({ ...req.body, userId: req.user.id }) }); } catch (e) { next(e); } }
export async function listNotifications(req, res, next) { try { res.json({ success: true, data: await Notification.find({ userId: req.user.id }).sort({ createdAt: -1 }) }); } catch (e) { next(e); } }
export async function markNotificationRead(req, res, next) { try { const item = await Notification.findOneAndUpdate({ _id: req.params.id, userId: req.user.id }, { read: true }, { new: true }); if (!item) throw new AppError("Notification not found", 404); res.json({ success: true, data: item }); } catch (e) { next(e); } }
