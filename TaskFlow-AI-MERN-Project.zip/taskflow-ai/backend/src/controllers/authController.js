import jwt from "jsonwebtoken";
import { User } from "../models/User.js";
import { env } from "../config/env.js";
import { AppError } from "../utils/AppError.js";
import { signAccessToken, signRefreshToken } from "../utils/tokens.js";

const refreshCookieName = "tf_refresh";

function refreshCookieOptions() {
  return {
    httpOnly: true,
    secure: env.nodeEnv === "production",
    sameSite: env.nodeEnv === "production" ? "none" : "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000
  };
}

function authPayload(user, res) {
  const refreshToken = signRefreshToken(user);
  res.cookie(refreshCookieName, refreshToken, refreshCookieOptions());
  return {
    user: { id: user.id, name: user.name, email: user.email, role: user.role, avatar: user.avatar },
    accessToken: signAccessToken(user),
    refreshToken
  };
}

export async function register(req, res, next) {
  try {
    const exists = await User.findOne({ email: req.body.email });
    if (exists) throw new AppError("Email already registered", 409);
    const user = await User.create(req.body);
    res.status(201).json({ success: true, data: authPayload(user, res) });
  } catch (error) { next(error); }
}

export async function login(req, res, next) {
  try {
    const user = await User.findOne({ email: req.body.email }).select("+password");
    if (!user || !(await user.comparePassword(req.body.password))) throw new AppError("Invalid credentials", 401);
    res.json({ success: true, data: authPayload(user, res) });
  } catch (error) { next(error); }
}

export async function refresh(req, res, next) {
  try {
    const refreshToken = req.body.refreshToken || req.cookies[refreshCookieName];
    if (!refreshToken) throw new AppError("Refresh token required", 400);
    const payload = jwt.verify(refreshToken, env.refreshSecret);
    const user = await User.findById(payload.sub);
    if (!user || user.tokenVersion !== payload.tokenVersion) throw new AppError("Invalid refresh token", 401);
    res.json({ success: true, data: authPayload(user, res) });
  } catch (error) { next(new AppError("Invalid refresh token", 401)); }
}

export async function logout(req, res, next) {
  try {
    await User.findByIdAndUpdate(req.user.id, { $inc: { tokenVersion: 1 } });
    res.clearCookie(refreshCookieName, refreshCookieOptions());
    res.json({ success: true, message: "Logged out" });
  } catch (error) { next(error); }
}

export async function me(req, res) {
  res.json({ success: true, data: req.user });
}
