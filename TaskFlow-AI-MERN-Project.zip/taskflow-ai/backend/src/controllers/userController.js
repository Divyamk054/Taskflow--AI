import { User } from "../models/User.js";

export async function listUsers(_req, res, next) {
  try { res.json({ success: true, data: await User.find().select("name email role avatar createdAt") }); } catch (error) { next(error); }
}

export async function updateProfile(req, res, next) {
  try {
    const allowed = (({ name, avatar }) => ({ name, avatar }))(req.body);
    const user = await User.findByIdAndUpdate(req.user.id, allowed, { new: true, runValidators: true }).select("-password");
    res.json({ success: true, data: user });
  } catch (error) { next(error); }
}
