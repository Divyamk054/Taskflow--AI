import { body, param, query } from "express-validator";

export const idParam = [param("id").isMongoId()];
export const taskIdParam = [param("taskId").isMongoId()];
export const pagination = [query("page").optional().isInt({ min: 1 }), query("limit").optional().isInt({ min: 1, max: 100 })];
export const projectValidator = [body("title").trim().isLength({ min: 2 }), body("status").optional().isIn(["planning", "active", "on_hold", "completed", "archived"])];
export const projectUpdateValidator = [body("title").optional().trim().isLength({ min: 2 }), body("status").optional().isIn(["planning", "active", "on_hold", "completed", "archived"])];
export const taskValidator = [
  body("title").trim().isLength({ min: 2 }),
  body("projectId").isMongoId(),
  body("assignedTo").optional({ values: "falsy" }).isMongoId(),
  body("dueDate").optional({ values: "falsy" }).isISO8601(),
  body("priority").optional().isIn(["low", "medium", "high", "urgent"]),
  body("status").optional().isIn(["todo", "in_progress", "review", "done"])
];
export const taskUpdateValidator = [
  body("title").optional().trim().isLength({ min: 2 }),
  body("projectId").optional().isMongoId(),
  body("assignedTo").optional({ values: "falsy" }).isMongoId(),
  body("dueDate").optional({ values: "falsy" }).isISO8601(),
  body("priority").optional().isIn(["low", "medium", "high", "urgent"]),
  body("status").optional().isIn(["todo", "in_progress", "review", "done"])
];
export const workspaceValidator = [body("name").trim().isLength({ min: 2 })];
export const commentValidator = [body("taskId").isMongoId(), body("text").trim().isLength({ min: 1, max: 2000 })];
