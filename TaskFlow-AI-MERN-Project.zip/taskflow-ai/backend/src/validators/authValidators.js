import { body } from "express-validator";

export const registerValidator = [
  body("name").trim().isLength({ min: 2 }),
  body("email").isEmail().normalizeEmail(),
  body("password").isStrongPassword({ minLength: 8, minSymbols: 0 }),
  body("role").optional().isIn(["admin", "manager", "member"])
];

export const loginValidator = [body("email").isEmail().normalizeEmail(), body("password").notEmpty()];
