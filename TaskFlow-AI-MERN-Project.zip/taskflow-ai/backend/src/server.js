import { env } from "./config/env.js";
import { connectDB } from "./config/db.js";
import { app } from "./app.js";
import { logger } from "./utils/logger.js";

await connectDB();
app.listen(env.port, () => logger.info(`TaskFlow AI API running on ${env.port}`));
