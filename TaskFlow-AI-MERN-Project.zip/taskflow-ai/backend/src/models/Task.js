import mongoose from "mongoose";

const attachmentSchema = new mongoose.Schema({ filename: String, path: String, mimetype: String, size: Number }, { _id: false });

const taskSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  description: { type: String, default: "" },
  priority: { type: String, enum: ["low", "medium", "high", "urgent"], default: "medium" },
  dueDate: { type: Date },
  status: { type: String, enum: ["todo", "in_progress", "review", "done"], default: "todo" },
  assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  projectId: { type: mongoose.Schema.Types.ObjectId, ref: "Project", required: true },
  attachments: [attachmentSchema]
}, { timestamps: true });

taskSchema.index({ title: "text", description: "text" });
export const Task = mongoose.model("Task", taskSchema);
