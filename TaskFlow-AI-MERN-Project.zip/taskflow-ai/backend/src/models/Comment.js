import mongoose from "mongoose";

const commentSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  taskId: { type: mongoose.Schema.Types.ObjectId, ref: "Task", required: true },
  text: { type: String, required: true, trim: true, maxlength: 2000 }
}, { timestamps: true });

export const Comment = mongoose.model("Comment", commentSchema);
