import { Router } from "express";
import { authenticate } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import { loginValidator, registerValidator } from "../validators/authValidators.js";
import { login, logout, me, refresh, register } from "../controllers/authController.js";

export const authRoutes = Router();
authRoutes.post("/register", registerValidator, validate, register);
authRoutes.post("/login", loginValidator, validate, login);
authRoutes.post("/refresh", refresh);
authRoutes.post("/logout", authenticate, logout);
authRoutes.get("/me", authenticate, me);
