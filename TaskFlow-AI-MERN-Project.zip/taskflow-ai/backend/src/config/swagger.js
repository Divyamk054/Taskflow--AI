export const swaggerSpec = {
  openapi: "3.0.0",
  info: { title: "TaskFlow AI API", version: "1.0.0", description: "REST API for intelligent project and team management." },
  servers: [{ url: "/api/v1" }],
  components: { securitySchemes: { bearerAuth: { type: "http", scheme: "bearer", bearerFormat: "JWT" } } },
  security: [{ bearerAuth: [] }],
  paths: {
    "/auth/register": { post: { summary: "Create account", security: [], responses: { 201: { description: "Registered" } } } },
    "/auth/login": { post: { summary: "Login", security: [], responses: { 200: { description: "Authenticated" } } } },
    "/auth/refresh": { post: { summary: "Refresh access token", security: [], responses: { 200: { description: "Token refreshed" } } } },
    "/workspaces": { get: { summary: "List accessible workspaces" }, post: { summary: "Create workspace" } },
    "/projects": { get: { summary: "List projects with search and pagination" }, post: { summary: "Create project" } },
    "/projects/{id}": { patch: { summary: "Update project" }, delete: { summary: "Delete project and tasks" } },
    "/tasks": { get: { summary: "List authorized tasks with search and pagination" }, post: { summary: "Create task with optional attachments" } },
    "/tasks/{id}": { patch: { summary: "Update task status, assignment, deadline, or priority" }, delete: { summary: "Delete task" } },
    "/tasks/{taskId}/comments": { get: { summary: "List comments for an authorized task" } },
    "/comments": { post: { summary: "Add comment to a task" } },
    "/notifications": { get: { summary: "List current user notifications" } },
    "/notifications/{id}/read": { patch: { summary: "Mark notification read" } },
    "/users": { get: { summary: "List users for admins and managers" } },
    "/users/me": { patch: { summary: "Update current user profile" } },
    "/analytics": { get: { summary: "Dashboard analytics scoped to accessible projects" } }
  }
};
