import jwt from "jsonwebtoken";
import { env } from "../config/env.js";

export function signAccessToken(user) {
  return jwt.sign({ sub: user.id, role: user.role, email: user.email }, env.accessSecret, { expiresIn: env.accessTtl });
}

export function signRefreshToken(user) {
  return jwt.sign({ sub: user.id, tokenVersion: user.tokenVersion }, env.refreshSecret, { expiresIn: env.refreshTtl });
}
