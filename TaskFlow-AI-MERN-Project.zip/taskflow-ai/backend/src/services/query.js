export function listQuery(req) {
  const page = Number(req.query.page || 1);
  const limit = Number(req.query.limit || 10);
  const skip = (page - 1) * limit;
  const search = req.query.search?.trim();
  return { page, limit, skip, search };
}

export async function paginated(model, filter, req, populate = []) {
  const { page, limit, skip, search } = listQuery(req);
  const finalFilter = search ? { ...filter, $text: { $search: search } } : filter;
  const [items, total] = await Promise.all([
    model.find(finalFilter).sort({ createdAt: -1 }).skip(skip).limit(limit).populate(populate),
    model.countDocuments(finalFilter)
  ]);
  return { items, page, pages: Math.ceil(total / limit) || 1, total };
}
