import jwt from "jsonwebtoken";
import { User } from "../models/User.js";
import { env } from "../config/env.js";
import { AppError } from "../utils/AppError.js";

export async function authenticate(req, _res, next) {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : null;
    if (!token) throw new AppError("Authentication required", 401);
    const payload = jwt.verify(token, env.accessSecret);
    const user = await User.findById(payload.sub).select("-password");
    if (!user) throw new AppError("User no longer exists", 401);
    req.user = user;
    next();
  } catch {
    next(new AppError("Invalid or expired access token", 401));
  }
}

export function authorize(...roles) {
  return (req, _res, next) => {
    if (!roles.includes(req.user.role)) return next(new AppError("Insufficient permissions", 403));
    next();
  };
}
