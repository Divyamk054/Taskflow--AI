import { StatusCodes } from "http-status-codes";
import { logger } from "../utils/logger.js";

export function notFound(req, _res, next) {
  const error = new Error(`Route not found: ${req.method} ${req.originalUrl}`);
  error.statusCode = StatusCodes.NOT_FOUND;
  next(error);
}

export function errorHandler(err, _req, res, _next) {
  const statusCode = err.statusCode || StatusCodes.INTERNAL_SERVER_ERROR;
  if (statusCode >= 500) logger.error(err.stack || err.message);
  res.status(statusCode).json({
    success: false,
    message: err.message || "Internal server error",
    details: err.details,
    stack: process.env.NODE_ENV === "production" ? undefined : err.stack
  });
}
