import multer from "multer";
import { env } from "../config/env.js";

const storage = multer.diskStorage({
  destination: env.uploadDir,
  filename: (_req, file, cb) => cb(null, `${Date.now()}-${file.originalname.replace(/\s+/g, "-")}`)
});

export const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });
