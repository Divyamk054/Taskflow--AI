# TaskFlow AI - Intelligent Project & Team Management Platform

TaskFlow AI is a production-style MERN SaaS project for internship submission. It includes a secure Express API, MongoDB/Mongoose schemas, JWT authentication with refresh tokens, a responsive React dashboard, CRUD workflows, analytics, tests, Swagger, Postman, Docker, and deployment notes.

## Tech Stack

- Backend: Node.js, Express.js, MongoDB, Mongoose, JWT, bcrypt, Helmet, CORS, rate limiting, Winston, Swagger
- Frontend: React, React Router, Axios, Context API, Recharts, Framer Motion, Lucide icons
- DevOps: Docker, Docker Compose, Nginx
- Testing: Jest, Supertest, MongoDB Memory Server

## Folder Structure

```text
backend/src/config
backend/src/controllers
backend/src/middleware
backend/src/models
backend/src/routes
backend/src/services
backend/src/validators
backend/src/utils
frontend/src/pages
frontend/src/components
frontend/src/hooks
frontend/src/services
frontend/src/context
frontend/src/layouts
frontend/src/routes
frontend/src/utils
docs
nginx
```

## Features

- Signup, login, logout, profile management
- Password hashing with bcrypt
- Access and refresh token implementation
- Protected routes and role-based access control
- Workspaces, projects, tasks, comments, notifications
- Task priorities, due dates, assignment, attachments, statuses
- Dashboard analytics with cards, progress, and charts
- Kanban task board
- Search and pagination
- Loading and error states
- Dark mode and mobile responsive UI
- Swagger API docs and Postman collection

## Quick Start

```bash
cd backend
npm install
copy .env.example .env
npm run dev
```

```bash
cd frontend
npm install
copy .env.example .env
npm run dev
```

Open `http://localhost:5173`.

## Docker

```bash
docker compose up --build
```

Open `http://localhost:8080`.

## API Documentation

- Swagger UI: `http://localhost:5000/api/docs`
- Postman collection: `docs/TaskFlow-AI.postman_collection.json`

## Tests

```bash
cd backend
npm test
```

## Deployment

See `docs/DEPLOYMENT.md` for Vercel, Render, and MongoDB Atlas steps.

## Architecture

See `docs/ARCHITECTURE.md`.
