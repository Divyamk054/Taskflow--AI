# Architecture

```mermaid
flowchart LR
  Browser["React Client\nRouter + Context + Axios"] --> Nginx["Nginx Reverse Proxy"]
  Nginx --> API["Express API\n/api/v1"]
  API --> Auth["JWT Auth\nAccess + Refresh"]
  API --> Services["Controllers + Services\nValidation + Errors"]
  Services --> Mongo["MongoDB Atlas or Docker Mongo"]
  API --> Swagger["Swagger UI\n/api/docs"]
```

## Backend

- `app.js` composes security middleware, request logging, API versioning, Swagger, and global errors.
- Models are isolated under `src/models`.
- Controllers keep HTTP concerns separate from reusable query helpers in `src/services`.
- Auth uses bcrypt password hashing, access tokens, refresh tokens, and token version invalidation on logout.
- RBAC is implemented through `authorize(...roles)`.

## Frontend

- React Router owns page routing and protected route guards.
- Context API owns authentication and theme state.
- Axios interceptors attach access tokens and perform refresh-token recovery.
- Pages include dashboard, projects, tasks, analytics, profile, settings, auth, and 404.

## Deployment

- Vercel serves the frontend.
- Render runs the backend web service.
- MongoDB Atlas provides the production database.
- Docker Compose provides local production-like orchestration with Nginx.
