# Deployment Guide

## MongoDB Atlas

1. Create an Atlas cluster and database user.
2. Add the Render outbound IP range or allow your deployment environment.
3. Copy the connection string into `MONGO_URI`.

## Render Backend

1. Create a new Web Service from the repository.
2. Root directory: `backend`.
3. Build command: `npm install`.
4. Start command: `npm start`.
5. Add environment variables from `backend/.env.example`.
6. Set `CLIENT_URL` to the Vercel frontend URL.

## Vercel Frontend

1. Import the repository into Vercel.
2. Root directory: `frontend`.
3. Build command: `npm run build`.
4. Output directory: `dist`.
5. Add `VITE_API_URL=https://your-render-service.onrender.com/api/v1`.

## Docker Local Production

```bash
docker compose up --build
```

- Frontend through Nginx: `http://localhost:8080`
- Backend health: `http://localhost:5000/health`
- Swagger: `http://localhost:5000/api/docs`
