# Screenshots Checklist

Capture these screens for internship submission after running the app:

1. Register page
2. Login page
3. Dashboard with analytics cards and weekly chart
4. Projects CRUD screen with search and pagination
5. Tasks Kanban board
6. Analytics chart
7. Profile management screen
8. Swagger API documentation at `/api/docs`
9. Postman collection run summary
10. Docker Compose running containers

Suggested command:

```bash
docker compose up --build
```

Then open `http://localhost:8080`.
